import { CardInfoCharacter } from "../components/CardInfoCharacter"

export const InfoIndividual = ()=>{

    return (
            
            <CardInfoCharacter/>


    )
}